package com.saborurbano.restaurante.service.Categoria;

import java.util.List;

import com.saborurbano.restaurante.model.Categoria;

public interface CategoriaServiceInt {

    List<Categoria> getAllCategorias();

}
