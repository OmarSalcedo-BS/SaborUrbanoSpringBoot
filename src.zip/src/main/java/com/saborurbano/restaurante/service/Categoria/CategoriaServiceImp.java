package com.saborurbano.restaurante.service.Categoria;

import java.util.List;

import org.springframework.stereotype.Service;

import com.saborurbano.restaurante.model.Categoria;
import com.saborurbano.restaurante.repository.CategoriaRepository;

@Service
public class CategoriaServiceImp implements CategoriaServiceInt {

    private final CategoriaRepository categoriaRepository;

    public CategoriaServiceImp(CategoriaRepository categoriaRepository) {
        this.categoriaRepository = categoriaRepository;
    }

    @Override
    public Categoria registrarCategoria(Categoria categoria) {
        return categoriaRepository.save(categoria);
    }

    @Override
    public List<Categoria> getAllCategorias() {
        return categoriaRepository.findAll();
    }

    @Override
    public Categoria getCategoriaById(Long id) {
        return categoriaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Error de Negocio: La categoria con ID " + id + " no existe."));
    }

    @Override
    public void deleteCategoria(Long id) {
        categoriaRepository.findById(id).ifPresentOrElse(c -> {
            categoriaRepository.deleteById(id);
        }, () -> {
            throw new IllegalArgumentException("La categoria con ID " + id + " no existe.");
        });
    }
}
