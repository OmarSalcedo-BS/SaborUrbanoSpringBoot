package com.saborurbano.restaurante.service.CalificacionPlatillo;

import java.util.List;

import org.springframework.stereotype.Service;

import com.saborurbano.restaurante.model.CalificacionPlatillo;
import com.saborurbano.restaurante.model.Platillo;
import com.saborurbano.restaurante.model.Usuarios;
import com.saborurbano.restaurante.repository.CalificacionPlatilloRepository;
import com.saborurbano.restaurante.repository.PlatilloRepository;
import com.saborurbano.restaurante.repository.UsuariosRepository;

@Service
public class CalificacionPlatilloServiceImp implements CalificacionPlatilloServiceInt {

    private final CalificacionPlatilloRepository calificacionRepository;
    private final UsuariosRepository usuariosRepository;
    private final PlatilloRepository platilloRepository;

    public CalificacionPlatilloServiceImp(
            CalificacionPlatilloRepository calificacionRepository,
            UsuariosRepository usuariosRepository,
            PlatilloRepository platilloRepository
    ) {
        this.calificacionRepository = calificacionRepository;
        this.usuariosRepository = usuariosRepository;
        this.platilloRepository = platilloRepository;
    }

    @Override
    public CalificacionPlatillo registrarCalificacion(CalificacionPlatillo calificacion, Integer idUsuario, Long idPlatillo) {
        Usuarios usuario = usuariosRepository.findById(idUsuario)
                .orElseThrow(() -> new RuntimeException("Error de Negocio: El usuario con ID " + idUsuario + " no existe."));

        Platillo platillo = platilloRepository.findById(idPlatillo)
                .orElseThrow(() -> new RuntimeException("Error de Negocio: El platillo con ID " + idPlatillo + " no existe."));

        calificacion.setUsuario(usuario);
        calificacion.setPlatillo(platillo);

        return calificacionRepository.save(calificacion);
    }

    @Override
    public List<CalificacionPlatillo> getAllCalificaciones() {
        return calificacionRepository.findAll();
    }

    @Override
    public CalificacionPlatillo getCalificacionById(Long id) {
        return calificacionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Error de Negocio: La calificacion con ID " + id + " no existe."));
    }

    @Override
    public void deleteCalificacion(Long id) {
        calificacionRepository.findById(id).ifPresentOrElse(c -> {
            calificacionRepository.deleteById(id);
        }, () -> {
            throw new IllegalArgumentException("La calificacion con ID " + id + " no existe.");
        });
    }
}
